def head(L):
    return L[0]
 
def tail(L):
    return L[1]

def py2ll(L):
    # TODO
    return None

def ll2py(L):
    # TODO
    return []

def size(L):
    # TODO
    return 0

def sorted(L):
    # TODO
    return False

def sum(L):
    # TODO
    return 0

def split(L):
    # TODO
    return None

def merge(L0, L1):
    # TODO
    return None

def mSort(L):
    # TODO
    return None

def max(L):
    # TODO
    return 0

def get(L, N):
    # TODO
    return None